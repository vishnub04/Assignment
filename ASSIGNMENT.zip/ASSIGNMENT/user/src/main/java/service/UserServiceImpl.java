package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.UserDAOImpl;
import model.LoginDTO;
import model.UserDTO;

@Service
@Transactional

public class UserServiceImpl implements UserService {
	
@Autowired
UserDAOImpl userDAO;
	@Override
	public void addUser(UserDTO user) throws Exception {
		UserDTO userVer=new UserDTO();
		userVer=userDAO.getUser(user.getUserName());
		if(userVer==null) {
		
		userDAO.addUser(user);
	}
		if(userVer!=null) {
			throw new Exception("Service.USER_ALREADY_EXISTS");

		}
	}
	
	@Override
	public LoginDTO authenticateUser(LoginDTO user) throws Exception{
		LoginDTO user1=userDAO.authenticateUser(user);
		if(user1==null) throw new Exception("Service.INVALID_USERNAME");
		if(!user1.getPassword().equals(user.getPassword())) {
			throw new Exception("Service.INVALID_PASSWORD");
		}
		return user1;
		
	}
}
	
