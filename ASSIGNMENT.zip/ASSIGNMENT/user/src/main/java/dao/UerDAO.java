package dao;


import model.LoginDTO;
import model.UserDTO;

public interface UerDAO {
	public void addUser(UserDTO user)throws Exception;
	public LoginDTO authenticateUser(LoginDTO user)throws Exception;
}
