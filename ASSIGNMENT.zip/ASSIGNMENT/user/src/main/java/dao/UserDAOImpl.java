package dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import entity.UserEntity;
import model.LoginDTO;
import model.UserDTO;

@Repository
public class UserDAOImpl implements UerDAO{
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void addUser(UserDTO user)throws Exception{
		UserEntity userEntity=new UserEntity();
		userEntity.setUserName(user.getUserName());
		userEntity.setPassword(user.getPassword());
		userEntity.setAge(user.getAge());
		userEntity.setEmailId(user.getEmailId());
		userEntity.setPhoneNumber(user.getPhoneNumber());
		em.persist(userEntity);
	}
	
	@Override
	public LoginDTO authenticateUser(LoginDTO user) throws Exception {		
		UserEntity userlist=em.find(UserEntity.class,user.getUserName());
		if(userlist==null) {
			return null;
		}
		LoginDTO user1=new LoginDTO();
		user1.setPassword(userlist.getPassword());
		user1.setUserName(userlist.getUserName());
		return user1;
	}
	
	public UserDTO getUser(String userName) throws Exception{
		UserEntity userEntity=em.find(UserEntity.class,userName);
		if(userEntity==null) return null;
		else {
		UserDTO userVer=new UserDTO();
		userVer.setUserName(userEntity.getUserName());
		userVer.setPassword(userEntity.getPassword());
		userVer.setAge(userEntity.getAge());
		userVer.setPhoneNumber(userEntity.getPhoneNumber());
		userVer.setEmailId(userEntity.getEmailId());
		return userVer;
		}
	}

	
	
}
