package userAPI;

import org.json.simple.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import model.LoginDTO;
import model.UserDTO;

import service.UserService;



@RestController
@CrossOrigin
public class UserAPI {



	@Autowired
	UserService userService;
	@Autowired


	@PostMapping(value="/user/signup" )
	public JSONObject registerUser(@RequestBody UserDTO userDetails) throws Exception {
	try {
		 userService.addUser(userDetails);
		 JSONObject j=new JSONObject();
		 j.put("User","successfully_added");
		 return j;
		 
	} catch (Exception e) {
        throw e;
    }
	}
	
	@PostMapping(value = "/userlogin")
	public JSONObject authenticateUser(@RequestBody LoginDTO logindetails) throws Exception{
		try {
			
			userService.authenticateUser(logindetails);
			JSONObject j=new JSONObject();
			j.put("User", "Authenticated");
			
			return j;	
	}catch(Exception e) {
		throw e;
	}
	}
	}
