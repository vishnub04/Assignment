package Theatre.Theatre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatreApplicationTests {

	@Test
	void contextLoads() {
	}

}
