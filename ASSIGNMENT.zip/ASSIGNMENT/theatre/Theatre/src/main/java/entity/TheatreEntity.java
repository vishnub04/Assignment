package entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="vishnuassign")
public class TheatreEntity {
	@Id
	private String theatre_name;
	private String theatre_location;
	private Integer price;
	private Integer rating;
	private Integer seatingCapactity;
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public Integer getSeatingCapactity() {
		return seatingCapactity;
	}
	public void setSeatingCapactity(Integer seatingCapactity) {
		this.seatingCapactity = seatingCapactity;
	}
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public String getTheatre_location() {
		return theatre_location;
	}
	public void setTheatre_location(String theatre_location) {
		this.theatre_location = theatre_location;
	}

}
