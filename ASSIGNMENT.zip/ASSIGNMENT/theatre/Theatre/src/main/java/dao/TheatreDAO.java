package dao;

import java.util.List;

import entity.TheatreEntity;
import model.TheatreDTO;

public interface TheatreDAO {
	public void addTheatre(TheatreDTO theatre) throws Exception;
	public Boolean updateTheatre(TheatreDTO theatre) throws Exception;
	public Boolean deleteTheatre(TheatreDTO theatre) throws Exception;
	public List<TheatreEntity> getTheatre() throws Exception;
}
