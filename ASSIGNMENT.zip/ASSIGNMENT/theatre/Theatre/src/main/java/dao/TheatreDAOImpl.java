package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import entity.TheatreEntity;
import model.TheatreDTO;

@Repository
public class TheatreDAOImpl implements TheatreDAO{

	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void addTheatre(TheatreDTO theatre) throws Exception {
		try {
			
	
		TheatreEntity theatreEntity=new TheatreEntity();
		theatreEntity.setTheatre_name(theatre.getTheatre_name());
		theatreEntity.setPrice(theatre.getPrice());
		theatreEntity.setTheatre_location(theatre.getTheatre_location());
		theatreEntity.setRating(theatre.getRating());
		theatreEntity.setSeatingCapactity(theatre.getSeatingCapacity());
		em.persist(theatreEntity);
	}catch( Exception e) {
		throw e;
	}
		}
	
	@Override
	public Boolean updateTheatre(TheatreDTO theatre) throws Exception {
	
		TheatreEntity theatreEntity=em.find(TheatreEntity.class,theatre.getTheatre_name());
		if(theatreEntity!=null) {
			Query query=em.createQuery("select a from TheatreEntity a where a.theatreName=?1");
			query.setParameter("theatreName", theatreEntity.getTheatre_name());
			List<TheatreEntity> theatreList=query.getResultList();
			
			for(TheatreEntity a: theatreList) {
				
				a.setPrice(theatre.getPrice());
				a.setRating(theatre.getRating());
				a.setSeatingCapactity(theatre.getSeatingCapacity());
			}return true;
		}return false;
	
	}
	
	
	
	@Override
	public Boolean deleteTheatre(TheatreDTO theatre) throws Exception{
			TheatreEntity theatreEntity=em.find(TheatreEntity.class,theatre.getTheatre_name());
			if(theatreEntity!=null) {
				em.remove(theatreEntity);
			 return true;
			 }
			return false;
	
	}
	
	@Override
	public List<TheatreDTO> getTheatre() throws Exception{
			List<TheatreDTO> theatreList=new ArrayList<TheatreDTO>();
			Query query=em.createQuery("select u from theatreEntity u");
		
	}
	
}
